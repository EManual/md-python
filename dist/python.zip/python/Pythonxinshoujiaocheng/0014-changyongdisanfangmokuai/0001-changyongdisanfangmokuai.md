除了内建的模块外，Python还有大量的第三方模块。

基本上，所有的第三方模块都会在[PyPI - the Python Package Index](https://pypi.python.org/pypi)上注册，只要找到对应的模块名字，即可用easy_install或者pip安装。

本章介绍常用的第三方模块。

